#include "image.h"

//------------------------------------------------------------------------------
// nom : LAURETTA-PERONNE
// prenom : Aymerick
//
// Code source pour le projet d'UE035
// description : (les fonctions sont d�finit dans image.h)
//
// les pointeurs images dans ce code sont de type : struct fichierimage *
//
// fonction struct fichierimage * charger(char *)
// permet de charger une image presente sur le disque en memoire vive, la fonction
// renvoie un pointeur de type : struct fichierimage *
//
// fonction int enregistrer(struct fichierimage *,char *)
// permet d'enregistrer une image sur le disque sous le nom donn� en arg2, cette
// image est contenue dans une pointeur de type : struct fichierimage * fournit en arg1
//
// fonction struct fichierimage * nouveau(int,int)
// permet de creer une image en memoire de largeur arg1 et de hauteur arg2, la fonction
// retourne un pointeur de type : struct fichierimage *
//

// fonction void imageVersNiveauDeGris(struct fichierimage *fichier)
// permet de creer une image en memoire de niveau de gris, la fonction prend en
// parametre un pointeur de type : struct fichierimage *
// la fonction ne retourne rien
//
// void imageVersMirroir(struct fichierimage *fichier)
// permet de creer une image en mémoire de miroir, la fonction prend en parametre
// un pointeur de type : struct fichierimage *
// la fonction ne retourne rien
//
// void pivoterImageDroit(struct fichierimage *fichier)
// permet de creer une image en mémoire de pivoter à droite, la fonction prend en
// parametre un pointeur de type : struct fichierimage *
// la fonction ne retourne rien
//
// void pivoterImageGauche(struct fichierimage *fichier)
// permet de creer une image en mémoire de pivoter à gauche, la fonction prend en
// parametre un pointeur de type : struct fichierimage *
// la fonction ne retourne rien
//
// void convolution(struct fichierimage *fichier, int matrice[3][3], int diviseur)
// permet de creer une image en mémoire de convolution, la fonction prend en
// parametre un pointeur de type : struct fichierimage *, une matrice de convolution
// et un diviseur
// la fonction ne retourne rien
//------------------------------------------------------------------------------

int main() {
    // variable permettant le parcours d'une image
    int i, j;

    // exemple de déclarion d'un pointeur image
    struct fichierimage *fichier = NULL;
    struct fichierimage *fichier2 = NULL;

    // modification ou lecture de pixels d'une image
    /*
    fichier = nouveau(100, 100);
    for (i = fichier->entetebmp.hauteur; i >= 0; i--)
        for (j = 0; j < fichier->entetebmp.largeur; j++) {
            fichier->image[i][j].r = 0;
            fichier->image[i][j].g = 255;
            fichier->image[i][j].b = 255;
        }

    enregistrer("resultat.bmp", fichier);
    free(fichier);
    */

    // Effectue un copie coller d'une image dans un nouveau fichier .bmp
    /*
    fichier=charger("LAURETTA_PERONNE_Paysage.bmp"); // Charge mon Image .bmp t�l�charger depuis le web
    enregistrer("LAURETTA_PERONNE_resultat_Paysage.bmp",fichier); // Enregistre l'image t�l�charger sous un notre fichier
    free(fichier); // Libère la mémoire
    */

    // Menu de selection et affichage d'une image
    int choix = 10;
    while (choix != 0) {
        printf("Merci de bien voulori choisir l'action à effectuer");
        printf("\n  1. Une image en niveau de gris");
        printf("\n  2. Une image miroir");
        printf("\n  3. Une image symétrie");
        printf("\n  4. Une image pivot gauche");
        printf("\n  5. Une image pivot droite");
        printf("\n  7. Convolution de l'image");
        printf("\n  0. Quitter");

        printf("\nVotre choix : ");
        scanf("%d", &choix);

        if (choix == 1) {
            // Niveau de gris

            // Entrer le nom du fichier à charger
            char nom[100];
            printf("Entrer le nom du fichier à charger : ");
            scanf("%s", nom);

            // Charger l'image
            fichier = charger(nom); // Charge mon Image .bmp télécharger depuis le web
            // fichier = charger("LAURETTA_PERONNE_Lena.bmp"); // Charge mon Image .bmp télécharger depuis le web
            imageVersNiveauDeGris(fichier);                                          // Convertit l'image en niveau de gris
            enregistrer("LAURETTA_PERONNE_resultat_Lena_NiveauDeGris.bmp", fichier); // Enregistre l'image modifié sous un notre fichier
            system("start LAURETTA_PERONNE_resultat_Lena_NiveauDeGris.bmp");         // Ouverture de du fichier image dans la visionneuse
            free(fichier);                                                           // On Libère la mémoire
        } else if (choix == 2) {
            // Image Miroir

            fichier = charger("LAURETTA_PERONNE_Lena.bmp");
            imageVersMirroir(fichier);
            enregistrer("LAURETTA_PERONNE_resultat_Lena_Miroir.bmp", fichier);
            system("start LAURETTA_PERONNE_resultat_Lena_Miroir.bmp");
            free(fichier);
        } else if (choix == 3) {
            // Image symétrie

            fichier = charger("LAURETTA_PERONNE_Lena.bmp");
            imageVersSymetrie(fichier);
            enregistrer("LAURETTA_PERONNE_resultat_Lena_Symetrie.bmp", fichier);
            system("start LAURETTA_PERONNE_resultat_Lena_Symetrie.bmp");
            free(fichier);

        } else if (choix == 4) {
            // Image Pivot Gauche

            fichier = charger("LAURETTA_PERONNE_Lena.bmp");
            pivoterImageDroit(fichier);
            enregistrer("LAURETTA_PERONNE_resultat_Lena_PivotDroit.bmp", fichier);
            system("start LAURETTA_PERONNE_resultat_Lena_PivotDroit.bmp");
            free(fichier);
        } else if (choix == 5) {
            // Image Pivot Droite

            fichier = charger("LAURETTA_PERONNE_Lena.bmp");
            pivoterImageGauche(fichier);
            enregistrer("LAURETTA_PERONNE_resultat_Lena_PivotGauche.bmp", fichier);
            system("start LAURETTA_PERONNE_resultat_Lena_PivotGauche.bmp");
            free(fichier);
        } else if (choix == 6) {
            //code here
        } else if (choix == 7) {
            // convulation de l'image
            int i, j, diviseur;
            int masque[3][3];
            // int masque[3][3] = {{1, 1, 1}, {1, 1, 1}, {1, 1, 1}};
            // int masque[3][3] = {{1, 2, 1}, {2, 4, 2}, {1, 2, 1}};

            // Entrer le nom du fichier à charger
            char nom[100];
            printf("Entrer le nom du fichier à charger : ");
            scanf("%s", nom);

            // charger l'image
            fichier = charger(nom);
            // fichier = charger("LAURETTA_PERONNE_Lena.bmp");

            // Normalisation de l'image en fonction de la matrice de convolution
            printf("Valeur du diviseur afin de réalisation la normalisation  : \n");
            scanf("%d", &diviseur);

            // Masque de convulation 
            printf("Entrer le masque de convulation : \n");
            for (i = 0; i < 3; i++) {
                for (j = 0; j < 3; j++) {
                    scanf("%d", &masque[i][j]);
                }
            }
            printf("\n");
            printf("voici le masque saisie");
            printf("\n");
            for (i = 0; i < 3; i++) {
                for (j = 0; j < 3; j++) {
                    printf("%4d ", masque[i][j]);
                }
                printf("\n");
            }

            convolution(fichier, masque, diviseur);
            enregistrer("LAURETTA_PERONNE_resultat_Lena_Convolution.bmp", fichier);
            system("./LAURETTA_PERONNE_resultat_Lena_Convolution.bmp");
            free(fichier);

        } else if (choix == 0) {
            printf("Au revoir  \n");
        } else {
            printf("Votre choix n'est pas valide \n");
        }
    }
}
